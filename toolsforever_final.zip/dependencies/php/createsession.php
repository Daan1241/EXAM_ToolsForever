<?php
if (!isset($_SESSION)) { // Session not yet started.
    session_start();
}

?>