<?php
session_destroy();
$loggedIn = false;
?>
