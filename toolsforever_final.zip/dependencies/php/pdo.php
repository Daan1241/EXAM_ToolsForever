<?php
$dbservername = "localhost";
$dbusername = "root";
$dbpassword = ".Pixeltoothless124113350000MP"; // Sensitive data, do not commit to Github
$connection = new PDO("mysql:host=$dbservername:3306;dbname=toolsforever", $dbusername, $dbpassword);
?>